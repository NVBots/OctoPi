# Heated Chamber
Control the CISAAMHT chamber heater

## Installation
From the project root directory run `sudo python setup.py install`.