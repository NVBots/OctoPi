from setuptools import setup, find_packages

import sys
import os

setup(
    name='heated-chamber',
    version='0.0.3',
    description='Control the CISAAMHT chamber heater',
    author='Eric Hagemeyer',
    author_email='eric.hagemeyer@e-ci.com',
    url='https://github.com/NVBots/NVRaspiClient',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    install_requires=['MinimalModbus==0.7'],
)