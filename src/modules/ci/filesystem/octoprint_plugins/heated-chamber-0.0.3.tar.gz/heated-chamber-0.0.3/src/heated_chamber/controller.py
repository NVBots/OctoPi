import threading
from operator import lt, gt
from time import sleep
from .drivers import OmegaCN32PT
from .decorators import roundable
from functools import wraps

Driver = OmegaCN32PT
CONTROLLER_PORT = '/dev/chambertempctl'
DEFAULT_ROUNDING = 2


def use_default_rounding(func):
    @wraps(func)
    def decorated_func(*args, **kwargs):
        if 'round' not in kwargs:
            kwargs.update(round=DEFAULT_ROUNDING)
        return func(*args, **kwargs)
    return decorated_func


class HeatedChamber(object):
    def __init__(self, port=CONTROLLER_PORT, slave=1, driver=Driver):
        self._driver = driver(port, slave)

    @use_default_rounding
    def get_target(self, *args, **kwargs):
        return self._driver.get_setpoint_1(*args, **kwargs)

    def set_target(self, *args, **kwargs):
        return self._driver.set_setpoint_1(*args, **kwargs)

    @use_default_rounding
    def get_temp(self, *args, **kwargs):
        return self._driver.get_pv(*args, **kwargs)

    def clear(self):
        return self.set_target(0.0)

    def run(self):
        return self._driver.run()

    def idle(self):
        return self._driver.idle()

    def set_safety_start(self, enabled=True):
        return self._driver.set_safety_start(enabled)

    def get_safety_start(self):
        return self._driver.get_safety_start()

    def wait_for_temp(self, timeout=None, throttle=1):
        done = threading.Event()
        timer = threading.Timer(timeout, done.set)
        timer.start()
        reached_temp = False
        target = self.get_target()
        current_temp = self.get_temp()
        is_target_reached = lt if target < current_temp else gt
        while not done.is_set():
            if is_target_reached(self.get_temp(), self.get_target()):
                reached_temp = True
                done.set()
            else:
                sleep(throttle)
        if timer.is_alive():
            timer.cancel()
        return reached_temp


class HeatedChamberSimulator(HeatedChamber):
    _update_interval = 1
    _heating_rate = 1.35
    _cooling_rate = 1.35
    _target = 0
    _value = 0

    def __init__(self, update_interval=None, heating_rate=None, cooling_rate=None):
        self._driver = None
        if update_interval is not None:
            self._update_interval = update_interval
        if heating_rate is not None:
            self._heating_rate = heating_rate
        if cooling_rate is not None:
            self._cooling_rate = cooling_rate

        self._simulator_thread = threading.Thread(target=self._simulator_loop)
        self._simulator_thread.start()

    @use_default_rounding
    @roundable
    def get_target(self):
        return self._target

    def set_target(self, value):
        self._target = float(value)

    @use_default_rounding
    @roundable
    def get_temp(self):
        return self._value

    def _get_next_temperature(self):
        delta = self._target - self._value

        if delta > 0:
            change = self._heating_rate
        elif delta < 0:
            change = -self._cooling_rate
        else:
            change = 0
        
        if abs(change) > abs(delta):
            change = delta

        return self._value + change

    def _simulator_loop(self):
        while True:
            self._value = self._get_next_temperature()
            sleep(self._update_interval)

    def run(self):
        pass

    def idle(self):
        pass

    def set_safety_start(self, enabled=True):
        pass

    def get_safety_start(self):
        pass

