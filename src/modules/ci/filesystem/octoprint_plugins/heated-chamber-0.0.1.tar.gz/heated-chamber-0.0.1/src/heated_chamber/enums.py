from .utils import parse_flags

class DriverEnum:
    @classmethod
    def to_display(cls, value):
        return cls.name(value)

    @classmethod
    def name(cls, value):
        for key in cls.keys():
            if getattr(cls, key) == value:
                return key
        return value

    @classmethod
    def keys(cls):
        return filter(lambda key: key.isupper(), dir(cls))

    @classmethod
    def values(cls):
        return map(lambda key: getattr(cls, key), cls.keys())

    @classmethod
    def entries(cls):
        return map(lambda key: (key, getattr(cls, key)), cls.keys())


class DriverEnumFlags(DriverEnum):
    @classmethod
    def to_display(cls, value):
        return [cls.name(flag) for flag in cls.get_flags(value)]

    @classmethod
    def get_flags(cls, value):
        flags = parse_flags(value)
        if not len(flags):
            flags.append(0)
        return flags


class DriverEnumScale(DriverEnum):
    scale = []

    def __init__(self, *scale):
        self.scale = scale

    def name(self, value):
        return self.scale[value]

    def keys(self):
        return range(len(self.scale))

    def values(self):
        return self.scale

    def entries(self):
        return list(enumerate(self.scale))


class Control(DriverEnum):
    STOP = 0
    START = 1
    CANCEL = 2
    AUTO_ON = 3
    CONTINUOUS = 4

class ControlAction(DriverEnum):
    ACTION_REVERSE = 0
    ACTION_DIRECT = 1

class SystemState(DriverEnum):
    LOAD = 0
    IDLE = 1
    INPUT_ADJUST = 2
    CONTROL_ADJUST = 3
    MODIFY = 4
    WAIT = 5
    RUN = 6
    STANDBY = 7
    STOP = 8
    PAUSE = 9
    FAULT = 10
    SHUTDOWN = 11
    AUTOTUNE = 12

# Display and Formatting
class TimeFormat(DriverEnum):
    MINUTE_SECOND = 0
    HOUR_MINUTE = 1
    MILLISECONDS = 2
    HOUR_MINUTE_SECONDS = 3

class DecimalPoint(DriverEnum):
    POINT_NONE = 0
    POINT_3 = 1
    POINT_2 = 2
    POINT_1 = 3

class Units(DriverEnum):
    NONE = 0
    CELSIUS = 1
    FARENHEIT = 2

class Color(DriverEnum):
    OFF = 0
    GREEN = 1
    RED = 2
    AMBER = 3
    NO_CHANGE = 4

class Brightness(DriverEnum):
    LOW = 0
    MEDIUM = 1
    HIGH = 2

# Input Parameters
class Sensor(DriverEnum):
    TC = 0
    RTD = 1
    PROCESS = 2
    THERMISTOR = 3
    REMOTE = 4

class TCType(DriverEnum):
    J = 0
    K = 1
    T = 2
    E = 3
    N = 4
    R = 6
    S = 7
    B = 8
    C = 9

class SetpointMode(DriverEnum):
    ABSOLUTE = 0
    DEVIATION = 1
    REMOTE = 2
    EXTERNAL = 3
    RAMP_SOAK = 4

class OutputHWType(DriverEnumFlags):
    NONE = 0
    STR = 1
    SSR = 2
    DTR = 4
    DCP = 8
    ANG = 16
    IANG = 32
    IDC = 64


class OutputPolarity(DriverEnum):
    NORMALLY_OPEN = 0
    NORMALLY_CLOSED = 1

class OutputType(DriverEnum):
    VOLTAGE = 0
    CURRENT = 1

class OutputMode(DriverEnum):
    OFF = 0
    PID = 1
    ON_OFF = 2
    RETRANSMISSION = 3
    ALARM_1 = 4
    ALARM_2 = 5
    RAMP_EVENT = 6
    SOAK_EVENT = 7

class OutputProcessRange(DriverEnum):
    VDC_0_10 = 0
    VDC_0_5 = 1
    MA_0_20 = 2
    MA_4_20 = 3
    MA_0_24 = 4

# Communication Protocals
class Protocol(DriverEnum):
    OMEGA = 0
    MODBUS = 1

class DataFlow(DriverEnum):
    COMMAND = 0
    CONTINUOUS = 1

class SeparationCharacter(DriverEnum):
    SPACE = 0
    CR = 1

class ModbusProtocol(DriverEnum):
    RTU = 0
    ASCII = 1
    PDU = 2

class SerialMode(DriverEnum):
    RS232 = 0
    RS485 = 1

SerialBaudRate = DriverEnumScale(
    300,
    600,
    1200,
    2400,
    4800,
    9600,
    19200,
    38400,
    57600,
    115200,
)

class Parity(DriverEnum):
    NONE = 0
    ODD = 1
    EVEN = 2

DataBits = DriverEnumScale(7, 8)