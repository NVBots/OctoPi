import minimalmodbus

from .decorators import enum, roundable, non_volatile
from .constants import REGISTER_SIZE, DISABLE, ENABLE
from .utils import parse_output_hw_type
from . import enums, register as Register


class OmegaCN32PT(minimalmodbus.Instrument, object):

    # Overrides
    def write_register(self, *args, **kwargs):
        kwargs.update(functioncode=6)
        super(OmegaCN32PT, self).write_register(*args, **kwargs)

    # State
    @enum(enums.SystemState)
    def system_status(self):
        return self.read_register(Register.SYSTEM_STATUS)

    @roundable
    def get_pv(self):
        return self.read_float(Register.CURRENT_INPUT_VALUE)

    def factory_reset(self):
        self.write_register(Register.FACTORY_RESET, ENABLE)

    def run(self):
        self.write_register(Register.RUN_MODE, ENABLE)

    def stop(self):
        self.write_register(Register.RUN_MODE, DISABLE)

    @enum(enums.SystemState)
    def is_running(self):
        return self.read_register(Register.RUN_MODE)

    # Setpoints
    
    @roundable
    def get_control_setpoint(self):
        return self.read_float(Register.CONTROL_SETPOINT)

    @roundable
    def get_setpoint_1(self):
        return self.read_float(Register.CURRENT_SETPOINT_1)

    def set_setpoint_1(self, value):
        return self.write_float(Register.CURRENT_SETPOINT_1, value)

    @roundable
    def get_remote_setpoint(self):
        return self.read_float(Register.REMOTE_SETPOINT_VALUE)

    @roundable
    def get_setpoint_2(self):
        return self.read_float(Register.CURRENT_SETPOINT_2)

    def set_setpoint_2(self, value):
        return self.write_float(Register.CURRENT_SETPOINT_2, value)

    # display
    
    @enum(enums.Units)
    def get_display_units(self):
        return self.read_register(Register.DISPLAY_UNITS)

    @enum(enums.Brightness)
    def get_display_brightness(self):
        return self.read_register(Register.DISPLAY_BRIGHTNESS)

    @non_volatile
    def set_display_brightness(self):
        return self.write_register(Register.DISPLAY_BRIGHTNESS)

    @enum(enums.Color)
    def get_display_color(self):
        return self.read_register(Register.DISPLAY_COLOR_NORMAL)

    @non_volatile
    def set_display_color(self):
        return self.write_register(Register.DISPLAY_COLOR_NORMAL)

    # Config
    def get_pid_action(self):
        return self.read_register(Register.PID_ACTION)

    @enum(enums.SetpointMode)
    def get_setpoint_1_mode(self):
        return self.read_register(Register.SETPOINT_1_MODE)

    @roundable
    def get_absolute_setpoint_1(self):
        return self.read_float(Register.ABSOLUTE_SETPOINT_1)

    # Output
    def get_output_state(self, output):
        if output not in range(1, 8):
            raise ValueError('Output must be between 1 and 8')
        register = Register.OUTPUT_STATE - 1 + output
        state = self.read_register(register)
        return bool(state)

    def _get_output_register(self, output, address):
        return Register.OUTPUT_CONFIGS[output - 1] - Register.OUTPUT_CONFIGS[0] + address

    def _output_config_getter(base_register, **kwargs):
        is_float = kwargs.get('float', None)
        use_enum = kwargs.get('enum', None)
        def output_config_getter(self, output):
            register = self._get_output_register(output, base_register)
            if is_float:
                return self.read_float(register)
            else:
                return self.read_register(register)
        if is_float:
            return roundable(output_config_getter)
        elif use_enum:
            return enum(use_enum)(output_config_getter)
        else:
            return output_config_getter

    get_output_mode = _output_config_getter(Register.OUTPUT_MODE, enum=enums.OutputMode)
    get_output_on_off_action = _output_config_getter(Register.OUTPUT_ON_OFF_ACTION)
    get_output_setpoint = _output_config_getter(Register.OUTPUT_SETPOINT)
    get_output_pulse_length = _output_config_getter(Register.OUTPUT_PULSE_LENGTH, float=True)
    get_output_on_off_deadband = _output_config_getter(Register.OUTPUT_ON_OFF_DEADBAND, float=True)
    get_output_range = _output_config_getter(Register.OUTPUT_RANGE, enum=enums.OutputProcessRange)

    def get_output_hw_type(self, output, debug=False):
        register = self._get_output_register(output, Register.OUTPUT_HW_TYPE)
        instances, hw_types = parse_output_hw_type(self.read_register(register))
        if debug:
            hw_types = enums.OutputHWType.to_display(hw_types)
        return instances, hw_types
    
    def _get_config_settings(self, prefix):
        config_registers = [(key, getattr(Register, key)) for key in dir(Register) if key.startswith(prefix + '_')]
        config = {}
        for name, address in config_registers:
            config[name] = self.read_register(address)
        return config

    def get_usb_config(self):
        return self._get_config_settings('USB')

    def get_serial_config(self):
        return self._get_config_settings('SERIAL')

