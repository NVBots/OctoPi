import threading
from operator import lt, gt
from time import sleep
from .drivers import OmegaCN32PT
from functools import wraps

Driver = OmegaCN32PT
CONTROLLER_PORT = '/dev/chambertempctl'
DEFAULT_ROUNDING = 2


def use_default_rounding(func):
    @wraps(func)
    def decorated_func(*args, **kwargs):
        if 'round' not in kwargs:
            kwargs.update(round=DEFAULT_ROUNDING)
        return func(*args, **kwargs)
    return decorated_func


class HeatedChamber(object):
    def __init__(self, port=CONTROLLER_PORT, slave=1, driver=Driver):
        self.driver = driver(port, slave)

    @use_default_rounding
    def get_target(self, *args, **kwargs):
        return self.driver.get_setpoint_1(*args, **kwargs)

    def set_target(self, *args, **kwargs):
        return self.driver.set_setpoint_1(*args, **kwargs)

    @use_default_rounding
    def get_temp(self, *args, **kwargs):
        return self.driver.get_pv(*args, **kwargs)

    def clear(self):
        return self.set_target(0.0)

    def wait_for_temp(self, timeout=None, throttle=1):
        done = threading.Event()
        timer = threading.Timer(timeout, done.set)
        timer.start()
        reached_temp = False
        target = self.get_target()
        current_temp = self.get_temp()
        is_target_reached = lt if target < current_temp else gt
        while not done.is_set():
            if is_target_reached(self.get_temp(), self.get_target()):
                reached_temp = True
                done.set()
            else:
                sleep(throttle)
        if timer.is_alive():
            timer.cancel()
        return reached_temp