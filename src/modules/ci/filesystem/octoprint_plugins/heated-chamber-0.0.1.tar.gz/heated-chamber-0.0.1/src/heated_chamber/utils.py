from .constants import REGISTER_SIZE


def parse_output_hw_type(value):
    """The hw_type register uses the upper bits for instance count"""
    INSTANCE_BITS = 4

    mask = int('1' * INSTANCE_BITS, 2) << (REGISTER_SIZE - INSTANCE_BITS)
    hw_types = value - (mask & value)
    instances = (mask & value) >> (REGISTER_SIZE - INSTANCE_BITS)

    return instances, hw_types


def parse_flags(value):
    """Parse binary flags from value"""
    flags = []
    i = 0
    while 2 ** i <= value:
        flag = 2 ** i
        if value & flag:
            flags.append(flag)
        i += 1
    return flags

