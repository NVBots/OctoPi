from time import sleep
from functools import wraps


def enum(driver_enum):
    """Include DriverEnum to create decorator"""
    def decorator(func):
        """Decorator to return string value of driver_enum if debug"""
        @wraps(func)
        def debug_func(self, *args, **kwargs):
            debug = kwargs.pop('debug', False)
            val = func(self, *args, **kwargs)
            if debug:
                val = driver_enum.to_display(val)
            return val
        return debug_func
    return decorator


def roundable(func):
    """Decorator to round return value with ndigits param"""
    @wraps(func)
    def roundable_func(self, *args, **kwargs):
        ndigits = kwargs.pop('round', None)
        val = func(self, *args, **kwargs)
        if ndigits is not None:
            val = round(val, ndigits)
        return val
    return roundable_func


def non_volatile(func):
    """Wait a half second after writes"""
    @wraps(func)
    def nv_func(self, *args, **kwargs):
        val = func(self, *args, **kwargs)
        sleep(0.5)
        return val
    return nv_func