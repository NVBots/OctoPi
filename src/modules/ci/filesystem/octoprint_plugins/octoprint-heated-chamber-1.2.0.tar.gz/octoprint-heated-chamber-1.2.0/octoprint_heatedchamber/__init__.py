import threading
import time

import flask
from octoprint.plugin import SettingsPlugin, TemplatePlugin, AssetPlugin, SimpleApiPlugin, StartupPlugin, EventHandlerPlugin
from octoprint.settings import settings, default_settings
from heated_chamber import HeatedChamber, HeatedChamberSimulator

CHAMBER_TEMPERATURE_UPDATE = 'chamber_temperature_update'

HEATED_CHAMBER_INIT_RETRIES = 3
HEATED_CHAMBER_INIT_RETRY_DELAY = 2

class HeatedChamberPlugin(StartupPlugin, SettingsPlugin, SimpleApiPlugin, TemplatePlugin, AssetPlugin):
    def get_settings_defaults(self):
        return {
            'update_interval': 3,
            'enabled': True,
            'simulator': False,
            'port': '/dev/chambertempctl',
        }

    def get_api_commands(self):
        return dict(update=['value'])

    def get_template_configs(self):
        return [
            dict(type='tab', custom_bindings=True, replaces='temperature', name='Temperature'),
            dict(type='generic'),
        ]

    def get_assets(self):
        return {
            'js': ['heatedchamber.js']
        }

    def init_heated_chamber(self):
        port = self._settings.get(['port'])
        for retry in range(HEATED_CHAMBER_INIT_RETRIES):
            self._logger.info('Initializing Heated Chamber: %d / %d' % (retry, HEATED_CHAMBER_INIT_RETRIES))
            try:
                self.heated_chamber = HeatedChamber(port=port)
                self.heated_chamber.set_safety_start()
            except Exception as e:
                self._logger.error('Unable to initialize heated chamber %s', e)
                time.sleep(HEATED_CHAMBER_INIT_RETRY_DELAY)
            else:
                break

    def on_after_startup(self):
        if self._settings.get_boolean(['enabled']):
            if self._settings.get_boolean(['simulator']):
                self._logger.info('Using heated chamber simulator')
                self.heated_chamber = HeatedChamberSimulator()
            else:
                self.init_heated_chamber()
            self.start_temp_polling()

    def send_plugin_message(self, channel, message):
        payload = {
            'type': channel,
            'data': message,
        }
        self._plugin_manager.send_plugin_message(self._identifier, payload)

    def set_target(self, value):
        value = float(value)
        self._logger.info('Updating Target Temp: %f' % value)
        self.heated_chamber.run()
        self.heated_chamber.set_target(float(value))

    def get_target(self):
        return self.heated_chamber.get_target()

    def get_temp(self):
        return self.heated_chamber.get_temp()

    def get_temp_data(self):
        return {
            'value': self.get_temp(),
            'target': self.get_target(),
        }

    def on_api_get(self, request):
        return flask.jsonify(**self.get_temp_data())

    def on_api_command(self, command, data):
        if command == 'update':
            if 'value' in data:
                self.set_target(data['value'])

    def get_polling_interval(self):
        return self._settings.get_int(['update_interval'])

    def start_temp_polling(self):
        self.temp_polling_thread = threading.Thread(target=self.get_chamber_temp_updates)
        self.temp_polling_thread.start()

    def get_chamber_temp_updates(self):
        while True:
            try:
                temp_data = self.get_temp_data()
                self.send_plugin_message(CHAMBER_TEMPERATURE_UPDATE, temp_data)
            except Exception: 
                pass
            time.sleep(self.get_polling_interval())


__plugin_name__ = 'HeatedChamber'
__plugin_implementation__ = HeatedChamberPlugin()
