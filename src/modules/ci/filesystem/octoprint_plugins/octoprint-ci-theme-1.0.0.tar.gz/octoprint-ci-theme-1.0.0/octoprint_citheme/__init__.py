from octoprint.plugin import AssetPlugin


CSS_ASSETS = [
    'dist/style.css', 
    # 'dist/gridlex.min.css'
]

IMG_ASSETS = [
    'img/ci-logo.png',
]

class CITheme(AssetPlugin):
    def get_assets(self):
        return dict(css=CSS_ASSETS, img=IMG_ASSETS)

__plugin_name__ = 'CI-Theme'
__plugin_implementation__ = CITheme()