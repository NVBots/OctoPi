const path = require('path')

const STATIC_DIR = 'octoprint_removal/static';
const SRC_DIR = path.join(STATIC_DIR, 'src');
const DIST_DIR = path.join(STATIC_DIR, 'dist');

module.exports = {
    entry: path.resolve(SRC_DIR, 'removal.js'),
    mode: 'development',
    output: {
        path: path.resolve(__dirname, DIST_DIR),
        filename: 'removal.js'
    },
    module: {
        rules: [
        {
            test: /\.js$/,
            loader: 'babel-loader'
        }]
    },
    devtool: 'source-map'
}