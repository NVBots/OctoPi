from octoprint.printer.standard import Printer
from removal import REMOVAL_STATE

class RemovalPrinter(Printer):
    def is_printing(self):
        return self._comm is not None and (self._state == REMOVAL_STATE or self._comm.isPrinting())