import {autobind, enumerable} from 'core-decorators';
import {notify, confirm} from './notify';
import {pureComputed, OctoprintViewModel} from './octoUtils';

const BLADE_CALIBRATION_READY_MSG = 'Use the controls panel to raise the bed until blade is flush. Then press the Set Blade Height Button.';
const BLADE_NOT_CALIBRATED_MSG = `You haven't calibrated your blade height yet. This action may not work properly.`;

const confirmCalibration = confirm(BLADE_NOT_CALIBRATED_MSG, x => !x.pluginSettings.blade_height_configured());
const WEBCAM_IMAGE = '#removal_webcam_image';
const REMOVAL_TAB = '#tab_plugin_removal';

@OctoprintViewModel('#tab_plugin_removal', [
    'settingsViewModel',
    'printerStateViewModel', 
    'loginStateViewModel',
    'controlViewModel'
])
@autobind
class RemovalViewModel{
    constructor([settings, printerState, loginState, control]){
        this.settings = settings;
        this.printerState = printerState;
        this.loginState = loginState;
        this.control = control;
        this.removalDistance = ko.observable();
        this.fullRemovalDistance = 2000000;

        this.webcamDisableTimeout = undefined;
        this.webcamLoaded = ko.observable(false);
        this.webcamError = ko.observable(false);
        this.showWebcam = ko.observable(false);
    }

    @pureComputed
    webcamLoading(){
        return !this.webcamLoading() && !this.webcamError();
    }

    @pureComputed
    removalEnabled(){
        return this.printerState.isOperational() &&
            !this.printerState.isPrinting() &&
            this.loginState.isUser();
    }

    onBeforeBinding(){
        this.pluginSettings = this.settings.settings.plugins.removal;
        this.fullRemovalDistance = this.pluginSettings.max_time();
        this.removalDistance(this.fullRemovalDistance / 2);
    }

    onDataUpdaterPluginMessage(plugin, data){
        if(plugin !== 'removal') return;

        if(data.type === 'SafeStartFailed'){
            notify.error('Safe Start Failed', data.data);
        } else if (data.type === 'RemovalFailed'){
            notify.error('Removal Failure', data.data);
        } else if (data.type === 'BladeCalibrationReady'){
            notify.success('Blade Calibration Ready', BLADE_CALIBRATION_READY_MSG);
        }
    }

    onEventSettingsUpdated(payload){
        this._enableWebcam();
    }

    onTabChange(current, previous){
        console.log(current);
        if(current = REMOVAL_TAB){
            this._enableWebcam();
        } else if(previous == REMOVAL_TAB){
            this._disableWebcam();
        }
    }

    onBrowserTabVisibilityChange(status){
        if(status){
            this._enableWebcam();
        } else {
            this._disableWebcam();
        }
    }

    onAllBound(allViewModels){
        this._enableWebcam();
    }

    apiCommand(command, data){
        return OctoPrint.simpleApiCommand('removal', command, data);
    }
    
    moveBlade(vm, evt){
        let removalDistance = '';
        let direction = ($(evt.currentTarget).data('direction') || '').toUpperCase();
        let moveToEndstop = ($(evt.currentTarget).data('full-distance') || false);
        if(!moveToEndstop){
            removalDistance = this.removalDistance();
        }
        this.apiCommand('moveblade', {
            duration: removalDistance,
            reverse: (direction === 'B')
        }).done(res => console.log(res));
    }

    dropBed(vm, evt){
        OctoPrint.control.sendGcode('G27');
    }
    
    @confirmCalibration
    raiseBedToBlade(){
        this.apiCommand('raisebed');
    }
    
    @confirmCalibration
    runRemovalRoutine(){
        this.apiCommand('start');
    }
    
    setBladeHeight(){
        this.apiCommand('getbladeheight').done(data => {
            showConfirmationDialog(`This will set your blade height to ${data.bladeheight}.`, evt => {
                this.apiCommand('setbladeheight').done(data => {
                    this.pluginSettings.blade_height(data.bladeheight);
                    this.pluginSettings.blade_height_configured(true);
                    notify.success('Blade Height Updated', `Blade height is now set to ${data.bladeheight}`);
                })
            })
        });
    }
    
    prepareCalibration(){
        this.apiCommand('preparecalibration')
        .success(data => console.log(data))
        .fail(data => console.error(data))
        .done(data => {
            notify('notice', 'Preparing Blade Height Calibration', '', {hide: true});
        })
    }

    _disableWebcam(){
        if (OctoPrint.coreui.browser.safari) {
            return;
        }

        let timeout = this.control.settings.webcam_streamTimeout() || 5;
        this.webcamDisableTimeout = setTimeout(() => {
            console.log('Unloading webcam stream');
            $(WEBCAM_IMAGE).attr('src', '');
            this.webcamLoaded(false);
        }, timeout * 1000)
    }

    _enableWebcam(){

        console.log('Enabling webcam');

        if (OctoPrint.coreui.selectedTab != REMOVAL_TAB || !OctoPrint.coreui.browserTabVisible) {
            return;
        }

        if(this.webcamDisableTimeout != undefined){
            clearTimeout(this.webcamDisableTimeout);
        }

        let webcamImage = $(WEBCAM_IMAGE);
        let currentSrc = webcamImage.attr('src');

        // safari bug doesn't release the mjpeg stream, so we just set it up the once
        if (OctoPrint.coreui.browser.safari && currentSrc != undefined) {
            return;
        }

        let newSrc = this.control.settings.webcam_streamUrl();
        if(newSrc && currentSrc != newSrc) {
            if(newSrc.lastIndexOf('?') > -1){
                newSrc += '&';
            } else {
                newSrc += '?';
            }

            newSrc += new Date().getTime();

            this.webcamLoaded(false);
            this.webcamError(false);
            this.showWebcam(true);
            webcamImage.attr('src', newSrc);
        }
    }

    onWebcamLoaded(){
        if(this.webcamLoaded()) return;

        console.log('Webcam stream loaded');
        this.webcamLoaded(true);
        this.webcamError(false);
    }

    onWebcamErrored(){
        console.log('Webcam stream failed to load/disabled');
        this.webcamLoaded(false);
        this.webcamError(true);
    }
}