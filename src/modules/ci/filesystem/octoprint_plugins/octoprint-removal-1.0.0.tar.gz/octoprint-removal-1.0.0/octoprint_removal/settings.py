TYPE_NAME = {
    int: 'Int',
    float: 'Float',
    bool: 'Boolean'
}

def get_method_name(value):
    return 'get%s' % TYPE_NAME[type(value)]

def set_method_name(value):
    return 'set%s' % TYPE_NAME[type(value)]

class PluginSettingsProxy(object):
    def __init__(self, target):
        self._target = target
        self._settings = target._settings
        self._default_settings = target.get_settings_defaults()

    def get(self, key, default=None):
        default_value = self._default_settings[key]
        get_method = getattr(self._target._settings, get_method_name(default_value))
        return get_method([key])

    def set(self, key, value):
        default_value = self._default_settings[key]
        set_method = getattr(self._target._settings, set_method_name(default_value))
        set_method([key], value)
        return self._target._settings.save()

    def __getitem__(self, key):
        return self.get(key)

    def __setitem__(self, key, value):
        return self.set(key, value)

    def __iter__(self):
        return iter(self._default_settings)

    def __repr__(self):
        return repr(self.__dict__())

    def __str__(self):
        return str(self.__dict__())

    def __dict__(self):
        return {key: self.get(key) for key in self}

    def items(self):
        return [(key, self.get(key)) for key in self]



class PluginSettingsMixin(object):
    def __init__(self, *args, **kwargs):
        super(PluginSettingsMixin, self).__init__(*args, **kwargs)
        self.plugin_settings = PluginSettingsProxy(self)
