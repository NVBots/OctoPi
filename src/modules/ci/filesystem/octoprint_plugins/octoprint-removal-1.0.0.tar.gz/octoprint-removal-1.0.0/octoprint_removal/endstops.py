import re, threading

from octoprint.printer import PrinterCallback


endstop_regex = re.compile('(?P<endstop>\w+):\s(?P<value>open|TRIGGERED)')
dcmoter_regex = re.compile('DCMotor Current Analog Reading:(?P<value>\d)')


# endstop keys
FRONTSTOP = 'frontstop'
BACKSTOP = 'backstop'
Z_MAX_ENDSTOP = 'z_max'

class EndstopException(Exception): pass
class FrontstopException(EndstopException): pass
class BackstopException(EndstopException): pass


class EndstopParser(PrinterCallback):
    def __init__(self):
        self.event = threading.Event()
        self.status = {}
        super(EndstopParser, self).__init__()

    def on_printer_add_message(self, data):
        endstop_match = endstop_regex.match(data)
        dcmoter_match = dcmoter_regex.match(data)
        if endstop_match:
            self.status[endstop_match.group('endstop')] = (endstop_match.group('value') == ENDSTOP_TRIGGERED)
        elif dcmoter_match:
            self.status['dcmoter'] = dcmoter_match.group('value')