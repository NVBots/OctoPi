
import {instanceDecorator} from './decoratorUtils';
import {autobind} from 'core-decorators';




export const pureComputed = instanceDecorator((instance, fn) => ko.pureComputed(fn, instance));

export function OctoprintViewModel(elements, deps){
    if(!Array.isArray(elements)){
        elements = [elements];
    }
    return function decorator(target){
        window.OCTOPRINT_VIEWMODELS.push([
            target,
            deps,
            elements
        ]);
        if(!target.prototype.hasOwnProperty('hasOwnProperty')){
            target.prototype.hasOwnProperty = function(prop){
                return this.__lookupGetter__(prop) ? true : Object.hasOwnProperty.call(this, prop);
            }
        }
        return target;
    }
}