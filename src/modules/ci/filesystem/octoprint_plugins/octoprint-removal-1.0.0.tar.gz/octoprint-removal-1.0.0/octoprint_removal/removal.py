import time

from .endstops import EndstopException, FrontstopException, BackstopException, FRONTSTOP, BACKSTOP, Z_MAX_ENDSTOP
from .utils import IS_VIRTUAL_PRINTER

REMOVAL_STATE = 15
REMOVAL_SIM_DURATION = 10

class RemovalFailure(Exception): pass


class RemovalMixin(object):
    def can_remove(self):
        return self._printer.is_operational() and not self._printer.is_printing()

    def move_blade(self, seconds=None, reverse=False, **kwargs):
        if seconds is None or str(seconds) == '':
            seconds = self.plugin_settings['max_time']
        seconds = seconds * 1000
        direction = 'B' if reverse else 'F'
        command = 'M68 {direction}{seconds}'.format(direction=direction, seconds=seconds)
        self.commands(command, **kwargs)

    def move_blade_back(self, seconds=None, **kwargs):
        return self.move_blade(seconds, True, **kwargs)

    def park_bed(self, **kwargs):
        return self.commands('G27', **kwargs)

    def raise_bed_to_blade(self, **kwargs):
        return self.commands('G0 Z%.2f F200' % self.plugin_settings['blade_height'], **kwargs)

    def safe_start(self):
        self._logger.info('Starting Safe Start')
        endstop = self.get_endstop_status()

        if endstop[BACKSTOP] and endstop[FRONTSTOP]:
            raise EndstopException('Frontstop and backstop are both triggered.')
        elif endstop[BACKSTOP]:
            self.move_blade(1)
            if self.get_endstop_status(BACKSTOP):
                raise BackstopException('Backstop is still triggered after moving the blade forwards.')
            self.move_blade_back(2)
        elif endstop[FRONTSTOP]:
            self.move_blade_back(1)
            if self.get_endstop_status(FRONTSTOP):
                raise FrontstopException('Frontstop is still open after moving the blade backwards.')
            self.move_blade_back()
        else:
            self.move_blade_back()
        endstop = self.get_endstop_status()

        if not endstop[BACKSTOP]:
            raise BackstopException('Backstop is not triggered after safe start.')
        elif endstop[FRONTSTOP]:
            raise FrontstopException('Frontstop is still triggered after safe start.')
        self._logger.info('Safe Start Completed')

    def prepare_removal(self):
        self.commands('G90')
        self.park_bed()

        if not self.get_endstop_status(Z_MAX_ENDSTOP):
            raise RemovalFailure('Z Max not triggered. Make sure there are no objects beneath the print plate.')

        self.move_blade(self.plugin_settings['align_time'])

    def simulate_removal(self):
        self._logger.info('Simulating Removal Routine')
        time.sleep(REMOVAL_SIM_DURATION)
        self._logger.info('Removal Routine Simulation Done')

    def remove(self):
        if IS_VIRTUAL_PRINTER:
            return self.simulate_removal()

        self._logger.info('Running Removal Routine')
        self.prepare_removal()

        self.raise_bed_to_blade()
        
        self.move_blade()
        self.move_blade_back(self.plugin_settings['return_time'])

        self.park_bed()
        self.move_blade_back()
        self._logger.info('Removal Routine Done')
