export function notify(type, title, message, options){
    let params = Object.assign({
        title: title || "",
        text: message || "",
        type: type,
        hide: false,
        buttons: {
            sticker: false
        }
    }, options || {});
    return new PNotify(params);
}

['success', 'error', 'notice', 'info'].forEach(type => {
    notify[type] = (...args) => notify(type, ...args);
});

export function confirm(message, predicate = () => true){
    return function(target, key, {value: fn, configurable, enumerable}){
        function decoratedFn(...args){
            if(predicate(this)){
                showConfirmationDialog(message, () => fn.apply(this, args));
            } else {
                fn.apply(this, args);
            }
        }

        return {
            configurable,
            enumerable,
            value: decoratedFn
        }
    }
}