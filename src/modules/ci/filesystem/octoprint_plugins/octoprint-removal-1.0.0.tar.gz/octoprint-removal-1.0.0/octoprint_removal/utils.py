import re
import uuid
import threading
import os
from itertools import count

from octoprint.printer import PrinterCallback
from octoprint.plugin import SimpleApiPlugin

from .endstops import EndstopParser

IS_VIRTUAL_PRINTER = os.environ.get('CI_VIRTUAL_PRINTER', False)

regex_float_pattern = "[-+]?[0-9]*\.?[0-9]+"
regex_positive_float_pattern = "[+]?[0-9]*\.?[0-9]+"
regex_int_pattern = "\d+"

position_regex = re.compile("X:(?P<x>{float})\s*Y:(?P<y>{float})\s*Z:(?P<z>{float})\s*E:(?P<e>{float})".format(float=regex_float_pattern))
endstop_regex = re.compile('(?P<endstop>\w+):\s(?P<value>open|TRIGGERED)')
dcmoter_regex = re.compile('DCMotor Current Analog Reading:(?P<value>\d)')


def checksum(line):
    return reduce(lambda x, y: x ^ y, map(ord, line))

def format_line(line, line_num=None):
    if line_num is not None:
        line = 'N%d %s' % (line_num, line)
    return '%s*%d' % (line, checksum(line))

def format_lines(lines, start=1):
    return map(lambda x: format_line(x[1], x[0] + start), enumerate(lines))


class WaitForMessage(PrinterCallback):
    def __init__(self, message, log_responses=True):
        self.event = threading.Event()
        self.message = message
        self.responses = []
        self.log_responses = log_responses
        super(WaitForMessage, self).__init__()

    def wait(self, timeout=None):
        return self.event.wait(timeout)

    def on_printer_add_message(self, data):
        if self.log_responses:
            self.responses.append(data)
        if re.search(self.message, data):
            self.event.set()


class StateContextManager(object):
    def __init__(self, printer, state, state_string):
        self.printer = printer
        self.state = state
        self.state_string = state_string
        self.set_old_state()

    def set_old_state(self):
        self.old_state = self.printer.get_state_id()
        self.old_state_string = self.printer.get_state_string()

    def __enter__(self):
        self.set_old_state()
        self.printer._setState(self.state, self.state_string)

    def __exit__(self, type, value, traceback):
        self.printer._setState(self.old_state, self.old_state_string)


class CallbackContextManager(object):
    def __init__(self, printer, callback):
        self.printer = printer
        self.callback = callback

    def __enter__(self):
        self.printer.register_callback(self.callback)

    def __exit__(self, type, value, traceback):
        self.printer.unregister_callback(self.callback)


class LineOrderContextManager(object):
    def __init__(self, controller, start=0):
        self.controller = controller
        self.start = start

    def __enter__(self):
        count = self.controller.reset_line_count(self.start)
        self.controller.start_line_manager(count)

    def __exit__(self, type, value, traceback):
        self.controller.stop_line_manager()


class PrinterUtils(object):
    CMD_ECHO = 'M38 S{}'
    CMD_ENDSTOP_STATUS = 'M119'
    CMD_CURRENT_POS = 'M114'
    CMD_RESET_LINES = 'M110'
    ENDSTOP_TRIGGERED = 'TRIGGERED'

    def __init__(self, *args, **kwargs):
        super(PrinterUtils, self).__init__(*args, **kwargs)
        self._state_stack = []
        self._line_manager = None

    def is_virtual_printer(self):
        connection_string, port, baudrate, printer_profile = self._printer.get_current_connection()
        return port == 'VIRTUAL'

    def start_line_manager(self, start=1):
        self._line_manager = count(start)

    def stop_line_manager(self):
        self._line_manager = None

    def reset_line_count(self, start=None):
        cmd = self.CMD_RESET_LINES
        if start is not None and start > 0:
            cmd = '%s N%d' % (cmd, start)
        else:
            start = 0
        self.commands(cmd)
        return start + 1

    def line_manager(self, start=0):
        return LineOrderContextManager(self, start)

    def push_state(self, state):
        old_state = self._printer._comm.getState()
        self._state_stack.append(old_state)
        self._printer._comm._changeState(state)
        return old_state

    def pop_state(self):
        state = self._state_stack.pop()
        self._printer._comm._changeState(state)
        return state

    def printer_state(self, state, state_string):
        return StateContextManager(self._printer, state, state_string)

    def printer_callback(self, callback):
        return CallbackContextManager(self._printer, callback)

    def commands(self, commands, timeout=None, line=None):
        done_token = uuid.uuid4().hex
        callback = WaitForMessage(done_token)

        if type(commands) is str:
            commands = [commands]

        commands.append('G4 P1')
        commands.append(self.CMD_ECHO.format(done_token))

        if line is not None:
            commands = format_lines(commands, line)
        elif self._line_manager:
            commands = map(lambda x: format_line(x, self._line_manager.next()), commands)

        with self.printer_callback(callback):
            self._printer.commands(commands)
            response = callback.wait(timeout)

        if response:
            return callback.responses
        else:
            return None

    def get_endstop_status(self, endstop=None):
        status = {}
        responses = self.commands(self.CMD_ENDSTOP_STATUS)
        if responses:
            for line in responses:
                endstop_match = endstop_regex.match(line)
                dcmoter_match = dcmoter_regex.match(line)
                if endstop_match:
                    status[endstop_match.group('endstop')] = (endstop_match.group('value') == self.ENDSTOP_TRIGGERED)
                elif dcmoter_match:
                    status['dcmoter'] = dcmoter_match.group('value')
        if endstop:
            return status[endstop]
        else:
            return status

    def get_current_position(self):
        position = {}
        responses = self.commands(self.CMD_CURRENT_POS)
        self._logger.info(responses)
        self._logger.info(position_regex)
        for msg in responses:
            match = position_regex.search(msg)
            if match:
                for key, value in match.groupdict().items():
                    position[key] = float(value)
        return position



def api_command(name, params=None):
    f = None

    # check if decorator was used without arguments
    if callable(name):
        f = name
        name = None

    # check if only params were sent
    if type(name) is list:
        params = name
        name = None

    if params is None:
        params = []

    def command_wrapper(f):
        f.api_command = {
            'name': name,
            'params': params
        }
        if not f.api_command['name']:
            f.api_command['name'] = f.__name__
        return f

    if f:
        return command_wrapper(f)
    else:
        return command_wrapper


def is_api_command(fn):
    return hasattr(fn, 'api_command') and callable(fn)


class ApiCommandPlugin(SimpleApiPlugin):
    def get_api_commands(self):
        return {
            fn.api_command['name']: fn.api_command['params'] 
            for fn in self.get_api_command_list()
        }

    def get_api_command_list(self):
        return filter(is_api_command, self.__class__.__dict__.itervalues())

    def on_api_command(self, command, data):
        command = filter(lambda x: x.api_command['name'] == command, self.get_api_command_list()).pop()
        return command(self, data)