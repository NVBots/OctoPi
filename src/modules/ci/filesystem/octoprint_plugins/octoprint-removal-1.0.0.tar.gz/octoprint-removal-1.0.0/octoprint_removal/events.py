SAFE_START_FAILED = 'SafeStartFailed'
REMOVAL_FAILED = 'RemovalFailed'
BLADE_CALIBRATION_READY = 'BladeCalibrationReady'