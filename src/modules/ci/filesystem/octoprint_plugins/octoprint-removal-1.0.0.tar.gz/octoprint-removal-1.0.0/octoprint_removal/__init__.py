import threading
import time
import flask
import re
import os
import uuid

from octoprint.plugin import SettingsPlugin, TemplatePlugin, AssetPlugin, SimpleApiPlugin, StartupPlugin, EventHandlerPlugin
from octoprint.util.comm import process_gcode_line
from octoprint.printer import PrinterCallback

from .utils import PrinterUtils, ApiCommandPlugin, api_command
from .settings import PluginSettingsMixin
from .removal import RemovalMixin, REMOVAL_STATE, RemovalFailure
from .endstops import EndstopException, FrontstopException, BackstopException, FRONTSTOP, BACKSTOP, Z_MAX_ENDSTOP
from .events import REMOVAL_FAILED, SAFE_START_FAILED, BLADE_CALIBRATION_READY
from .printer import RemovalPrinter

IS_VIRTUAL_PRINTER = os.environ.get('CI_VIRTUAL_PRINTER', False)

def respond_ok():
    return flask.jsonify({'success': True})


class RemovalPlugin(PrinterUtils, PluginSettingsMixin, RemovalMixin, TemplatePlugin, SettingsPlugin, 
                    AssetPlugin, ApiCommandPlugin, StartupPlugin, EventHandlerPlugin):
    if IS_VIRTUAL_PRINTER:
        CMD_ECHO = 'M117 {}'

    def on_after_startup(self):
        self._logger.info('REMOVAL PLUGIN')

    def send_plugin_message(self, channel, message):
        payload = {
            'type': channel,
            'data': message
        }
        self._plugin_manager.send_plugin_message(self._identifier, payload)

    def get_settings_defaults(self):
        return {
            'blade_height': 240.0,
            'align_time': 20,
            'return_time': 95,
            'max_time': 200,
            'blade_height_configured': False,
            'safe_start': True,
        }

    def get_template_vars(self):
        return self.plugin_settings.__dict__().update({'webcamStream': True})

    def get_template_configs(self):
        return [
            dict(type='settings', custom_bindings=False),
            dict(type='tab', custom_bindings=True)
        ]

    def get_assets(self):
        return {
            'js': ['dist/removal.js'],
            'img': ['img/removal-diagram.svg'],
        }

    @api_command('start')
    def cmd_start(self, data):
        self._logger.info('Start removal routine called')
        if not self.can_remove():
            error_message = 'Unable to run removal routine in current state'
            self._logger.error(error_message)
            return flask.make_response(error_message, 400)
        else:
            threading.Thread(target=self.try_remove).start()
            return respond_ok()

    @api_command('endstops')
    def cmd_endstops(self, data):
        return flask.jsonify(**self.get_endstop_status())

    @api_command('safestart')
    def cmd_safestart(self, data):
        threading.Thread(target=self.try_safe_start).start()
        return respond_ok()

    @api_command('raisebed')
    def cmd_raisebed(self, data):
        self.raise_bed_to_blade()
        return respond_ok()

    @api_command('moveblade', ['duration', 'reverse'])
    def cmd_moveblade(self, data):
        threading.Thread(
            target=self.move_blade,
            kwargs=dict(
                seconds=data.get('duration', None),
                reverse=data.get('reverse', False)
            )
        ).start()
        return respond_ok()

    @api_command('getbladeheight')
    def cmd_getbladeheight(self, data):
        position = self.get_current_position()
        return flask.jsonify({'bladeheight': str(position['z'])})

    @api_command('setbladeheight')
    def cmd_setbladeheight(self, data):
        position = self.get_current_position()
        self.plugin_settings['blade_height'] = position.get('z')
        return flask.jsonify({'bladeheight': str(position.get('z'))})

    @api_command('preparecalibration')
    def cmd_preparecalibration(self, data):
        threading.Thread(target=self.prepare_blade_height_calibration).start()
        return respond_ok()

    def on_event(self, event, payload):
        if event == 'Connected':
            self.on_connected(event, payload)

    def on_connected(self, event, payload):
        if self.plugin_settings['safe_start'] and not IS_VIRTUAL_PRINTER:
            self.try_safe_start()

    def prepare_blade_height_calibration(self):
        try:
            self.prepare_removal()
        except RemovalFailure as e:
            self._logger.error('Removal Failure: {}'.format(e.message))
            self.send_plugin_message(REMOVAL_FAILED, e.message)
        except Exception:
            self._logger.error('Unknown Removal Failure: {}'.format(e.message))
            self.send_plugin_message(REMOVAL_FAILED, 'Server Error')
        else:
            self.plugin_settings['blade_height_configured'] = True
            self.send_plugin_message(BLADE_CALIBRATION_READY, 'Blade Calibration Ready')

    def try_safe_start(self):
        try:
            self.safe_start()
        except Exception as e:
            message = e.message if isinstance(e, EndstopException) else 'Server Error'
            self._logger.error('safe start failed: {}'.format(e.message))
            self.send_plugin_message(SAFE_START_FAILED, message)

    def try_remove(self):
        with self.printer_state(REMOVAL_STATE, 'Removing'):
            try:
                self.remove()
            except RemovalFailure as e:
                self._logger.error('Removal Failure: %s' % e.message)
                self.send_plugin_message(REMOVAL_FAILED, e.message)




def printer_factory_hook(components, *args, **kwargs):
    return RemovalPrinter(
        components['file_manager'], 
        components['analysis_queue'], 
        components['printer_profile_manager']
    )


__plugin_name__ = 'Removal'
__plugin_implementation__ = RemovalPlugin()
__plugin_hooks__ = {
    'octoprint.printer.factory': printer_factory_hook
}