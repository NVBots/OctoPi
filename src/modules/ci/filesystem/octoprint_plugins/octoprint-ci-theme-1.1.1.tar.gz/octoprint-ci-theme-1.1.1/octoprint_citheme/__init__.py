from octoprint.plugin import AssetPlugin


CSS_ASSETS = [
    'dist/style.css', 
    # 'dist/gridlex.min.css'
]

FONT_ASSETS = [
    'fonts/roboto/Roboto-Black.woff',
    'fonts/roboto/Roboto-Black.woff2',
    'fonts/roboto/Roboto-BlackItalic.woff',
    'fonts/roboto/Roboto-BlackItalic.woff2',
    'fonts/roboto/Roboto-Bold.woff',
    'fonts/roboto/Roboto-Bold.woff2',
    'fonts/roboto/Roboto-BoldItalic.woff',
    'fonts/roboto/Roboto-BoldItalic.woff2',
    'fonts/roboto/Roboto-Light.woff',
    'fonts/roboto/Roboto-Light.woff2',
    'fonts/roboto/Roboto-LightItalic.woff',
    'fonts/roboto/Roboto-LightItalic.woff2',
    'fonts/roboto/Roboto-Medium.woff',
    'fonts/roboto/Roboto-Medium.woff2',
    'fonts/roboto/Roboto-MediumItalic.woff',
    'fonts/roboto/Roboto-MediumItalic.woff2',
    'fonts/roboto/Roboto-Regular.woff',
    'fonts/roboto/Roboto-Regular.woff2',
    'fonts/roboto/Roboto-RegularItalic.woff',
    'fonts/roboto/Roboto-RegularItalic.woff2',
    'fonts/roboto/Roboto-Thin.woff',
    'fonts/roboto/Roboto-Thin.woff2',
    'fonts/roboto/Roboto-ThinItalic.woff',
    'fonts/roboto/Roboto-ThinItalic.woff2',
]

IMG_ASSETS = [
    'img/ci-logo.png',
]

class CITheme(AssetPlugin):
    def get_assets(self):
        return dict(css=CSS_ASSETS, img=IMG_ASSETS, fonts=FONT_ASSETS)

__plugin_name__ = 'CI-Theme'
__plugin_implementation__ = CITheme()